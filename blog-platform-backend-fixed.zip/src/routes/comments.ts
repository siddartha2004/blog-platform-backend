import express from 'express';
const router = express.Router();

// Dummy placeholder routes
router.post('/:postId', (req, res) => res.send("Comment on post"));

export default router;