import express from 'express';
const router = express.Router();

// Dummy placeholder routes
router.get('/', (req, res) => res.send("Get all posts"));
router.post('/', (req, res) => res.send("Create post"));

export default router;