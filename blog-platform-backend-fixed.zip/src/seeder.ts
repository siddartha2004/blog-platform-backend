import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Post from './models/Post';

dotenv.config();

async function seedDB() {
  await mongoose.connect(process.env.MONGO_URI!);
  await Post.deleteMany({});
  await Post.insertMany([
    { title: 'Hello World', content: 'Welcome to the blog!', author: 'seed' }
  ]);
  console.log("Database seeded!");
  mongoose.disconnect();
}

seedDB();