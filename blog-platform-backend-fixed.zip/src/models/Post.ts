import mongoose from 'mongoose';

const PostSchema = new mongoose.Schema({
  title: String,
  content: String,
  author: String,
  createdAt: { type: Date, default: Date.now },
  likes: { type: Number, default: 0 },
});

export default mongoose.model('Post', PostSchema);